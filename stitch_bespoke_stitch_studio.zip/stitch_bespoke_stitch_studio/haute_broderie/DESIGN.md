---
name: Haute Broderie
colors:
  surface: '#fcf9f2'
  surface-dim: '#dcdad3'
  surface-bright: '#fcf9f2'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f6f3ec'
  surface-container: '#f1eee7'
  surface-container-high: '#ebe8e1'
  surface-container-highest: '#e5e2db'
  on-surface: '#1c1c18'
  on-surface-variant: '#4a4640'
  inverse-surface: '#31312c'
  inverse-on-surface: '#f3f0e9'
  outline: '#7b766f'
  outline-variant: '#ccc5bd'
  surface-tint: '#605e5c'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1c1b1a'
  on-primary-container: '#868382'
  inverse-primary: '#cac6c4'
  secondary: '#914b34'
  on-secondary: '#ffffff'
  secondary-container: '#ffa588'
  on-secondary-container: '#793823'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#261900'
  on-tertiary-container: '#9d8048'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e6e2df'
  primary-fixed-dim: '#cac6c4'
  on-primary-fixed: '#1c1b1a'
  on-primary-fixed-variant: '#484645'
  secondary-fixed: '#ffdbd0'
  secondary-fixed-dim: '#ffb59e'
  on-secondary-fixed: '#3a0b00'
  on-secondary-fixed-variant: '#73341f'
  tertiary-fixed: '#ffdea5'
  tertiary-fixed-dim: '#e4c284'
  on-tertiary-fixed: '#261900'
  on-tertiary-fixed-variant: '#5a4311'
  background: '#fcf9f2'
  on-background: '#1c1c18'
  surface-variant: '#e5e2db'
typography:
  display-lg:
    fontFamily: Bodoni Moda
    fontSize: 56px
    fontWeight: '400'
    lineHeight: 64px
    letterSpacing: -0.02em
  display-lg-mobile:
    fontFamily: Bodoni Moda
    fontSize: 36px
    fontWeight: '400'
    lineHeight: 44px
    letterSpacing: -0.01em
  display-sm:
    fontFamily: Bodoni Moda
    fontSize: 40px
    fontWeight: '400'
    lineHeight: 48px
    letterSpacing: -0.01em
  display-sm-mobile:
    fontFamily: Bodoni Moda
    fontSize: 28px
    fontWeight: '400'
    lineHeight: 36px
    letterSpacing: 0em
  headline-lg:
    fontFamily: Bodoni Moda
    fontSize: 32px
    fontWeight: '500'
    lineHeight: 40px
    letterSpacing: -0.01em
  headline-md:
    fontFamily: Bodoni Moda
    fontSize: 24px
    fontWeight: '500'
    lineHeight: 32px
    letterSpacing: 0em
  headline-sm:
    fontFamily: Bodoni Moda
    fontSize: 20px
    fontWeight: '600'
    lineHeight: 28px
    letterSpacing: 0.01em
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '400'
    lineHeight: 28px
    letterSpacing: 0em
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 15px
    fontWeight: '400'
    lineHeight: 24px
    letterSpacing: 0.01em
  body-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 13px
    fontWeight: '400'
    lineHeight: 20px
    letterSpacing: 0.015em
  label-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 14px
    fontWeight: '600'
    lineHeight: 18px
    letterSpacing: 0.08em
  label-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 12px
    fontWeight: '600'
    lineHeight: 16px
    letterSpacing: 0.12em
  label-sm:
    fontFamily: Plus Jakarta Sans
    fontSize: 10px
    fontWeight: '700'
    lineHeight: 14px
    letterSpacing: 0.16em
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  gutter: 1.5rem
  gutter-mobile: 1rem
  margin: 4rem
  margin-tablet: 2.5rem
  margin-mobile: 1.25rem
  space-xs: 0.25rem
  space-sm: 0.5rem
  space-md: 1rem
  space-lg: 1.75rem
  space-xl: 3rem
  space-2xl: 5rem
---

## Brand & Style

This design system establishes an atmospheric, tactile digital presence for a bespoke embroidered clothing atelier. The brand targets discerning patrons of couture, textile connoisseurs, and collectors of slow fashion who value provenance, artisanal heritage, and understated luxury over transient trends. 

The aesthetic is grounded in **Quiet Luxury and Editorial Fashion**, balanced with structural **Minimalism**:
- **Tactile Materiality:** Evoking natural raw silks, washed Belgian linens, heavy cotton twills, and metallic filaments. Interfaces feel physical, deliberate, and curated.
- **Museum-Grade Restraint:** White space is generous and intentional, treating garment photographs and intricate thread details as masterworks in an exhibition.
- **Editorial Poise:** High-contrast serif headlines evoke classical fashion broadsheets and archival art monographs, while precise utilitarian sans-serif accents present specifications (stitch counts, lot numbers, silk weights) with horological precision.
- **Sensory Rhythm:** Transitions are deliberate and frictionless, avoiding aggressive bounce in favor of soft, mechanical fades and whisper-quiet hover states.

## Colors

The palette reproduces the environment of a sunlit textile workshop: untreated canvas, deep carbon tailor’s chalk, vegetal dye baths, and gilded needlework.

### Role Mapping
- **Primary (`#1A1918` - Espresso Carbon):** The dominant structural color for critical typography, high-priority buttons, primary icons, and structural divider lines. Never harsh pure black, but an organic, ink-like deep charcoal.
- **Secondary (`#A45A42` - Terracotta Thread):** The active accent, reserved for tactile badges, curated collection callouts, subtle hover states, active stitch-selection indicators, and bespoke personalization steps.
- **Tertiary (`#C2A267` - Vintage Golden Wheat):** A metallic-adjacent accent denoting atelier credentials, archive editions, silk luster badges, and fine embroidery stitch counters.
- **Neutral (`#F5F2EB` - Unbleached Calico):** The structural base canvas. Layered alongside `#FAF8F5` (Parchment Silk) for body backgrounds and `#FFFFFF` (Pure Cotton Muslin) for raised elevated surfaces and image frames.

### Supporting Chromatics
- **Borders & Dividers:** Use `#E6E2DA` (Warp Thread) for standard separation and `#D8D2C7` (Weft Thread) for interactive borders and focused form fields.
- **Subdued Accents:** `#5B6B58` (Sage Thread) acts as an auxiliary contextual tone for sustainability notes, origin stamps, and natural fiber certifications.
- **Muted Text:** `#2A2825` (Charcoal Umber) for secondary copy; `#6B665F` (Flax Grey) for micro-metadata and legals.

## Typography

The typographic hierarchy marries the dramatic, razor-sharp stroke contrast of **Bodoni Moda** with the crystalline legibility and geometric poise of **Plus Jakarta Sans**.

### Typographic Principles
- **Headlines & Display:** Bodoni Moda is set with relaxed line heights to accommodate sweeping ascenders and descenders. High-impact editorial displays employ subtle negative tracking to preserve structural tension. Never use all-caps for Bodoni Moda beyond single-word accents.
- **Interface & Data:** Plus Jakarta Sans manages all functional components, prices, sizing guides, and technical stitch counts. 
- **Atelier Micro-Labels:** `label-sm` and `label-md` are explicitly designed for uppercase typesetting with wide letter-spacing (`0.12em` to `0.16em`) to mirror archival garment tags, stitch-density readouts, and fabrication origins.
- **Numbers & Currencies:** Currency marks and prices use tabular numerals (`font-variant-numeric: tabular-nums`) in Plus Jakarta Sans Medium to ensure seamless alignment across shopping bags and checkout summaries.

## Layout & Spacing

The layout philosophy mirrors high-fashion print publishing: asymmetrical balance, deep perimeter margins, and rhythmic horizontal rules that frame content rather than box it in.

### Grid Architecture
- **Desktop (12 Columns):** 12-column fluid grid constrained to a maximum content width of `1440px`. Column gutters remain steady at `1.5rem` (`24px`), flanked by expansive outer margins of `4rem` (`64px`) to create an airy gallery mat around the products.
- **Tablet (8 Columns):** Standard 8-column layout. Margin shrinks to `2.5rem` (`40px`), preserving gutters at `1.5rem`.
- **Mobile (4 Columns):** Strict 4-column framework. Side margins taper to `1.25rem` (`20px`) with gutters at `1rem` (`16px`).

### Vertical Rhythm & Negative Space
- **Breathing Cadence:** Product showcases alternate between full-width immersive macro-embroidery details and offset 2-column or 3-column asymmetric listings.
- **Section Pacing:** Major thematic shifts (e.g., bespoke inquiry form to fabric archive) require `space-2xl` (`5rem`) to maintain narrative independence.
- **Hairline Restraint:** Layout boundaries rely on structural margins rather than heavy card borders. Where separation is mandatory, apply single horizontal 1px hairline borders (`#E6E2DA`).

## Elevation & Depth

To preserve the authentic tactile quality of bespoke textiles, this design system rejects heavy digital dropshadows, intense blurs, and glossy volumetric gradients. Depth is achieved via **tonal stratification, hairline definition, and micro-diffusion**.

### Elevation Rules
- **Base Canvas (Level 0):** `#FAF8F5` (Parchment Silk) serves as the ambient environment for editorial articles and product listings.
- **Raised Surfaces (Level 1):** `#FFFFFF` (Pure White) surfaces for interactive cards, flyout drawers, and product detail modals. Edges are framed strictly with a 1px ghost border in `#E6E2DA`. No shadow is applied under static conditions.
- **Tactile Lift (Level 2 - Hover & Floating Controls):** Cart flyouts, bespoke stitch configurator tooltips, and elevated navigation bars utilize a bespoke shadow tinted with natural umber pigment:
  `box-shadow: 0 12px 32px -4px rgba(26, 25, 24, 0.04), 0 4px 12px -2px rgba(26, 25, 24, 0.02);`
- **Floating Modals & Lightboxes (Level 3):** Thread zoom viewers and high-res embroidery magnifiers sit on an ambient backdrop overlay tinted with `#1A1918` at 40% opacity with a subtle `backdrop-filter: blur(2px)`. The surface container floats with:
  `box-shadow: 0 24px 48px -12px rgba(26, 25, 24, 0.08);`

## Shapes

The atelier demands razor-sharp precision tempered by natural softness, mimicking hand-loomed cloth, cardstock tags, and bespoke fabric swatches.

### Corner Curvature
- **Form Factor `1` (Soft):** Structural UI elements utilize a minimal `0.25rem` (`4px`) radius. This subtle rounding eliminates digital harshness while maintaining the disciplined, architectural silhouettes characteristic of couture packaging.
- **Container Radii (`rounded-lg` - 0.5rem / 8px):** Applied to image viewports, zoom loupes, and modal cards.
- **Pill Exceptions (`rounded-full`):** Reserved exclusively for dynamic status chips, thread-color selector swatches, and small stitch-density metadata badges.

## Components

### Buttons & Action Triggers
- **Primary Action (Atelier Black):** Solid `#1A1918` background, `#FAF8F5` text. Minimal padding (`14px 28px`), typography set to `label-md` uppercase. Micro-interaction: Background shifts smoothly to `#A45A42` (Terracotta Thread) over `250ms ease-out` with no vertical displacement.
- **Secondary Action (Hairline Wire):** Transparent background, 1px border in `#1A1918`, text in `#1A1918`. On hover, the container fills with `#F5F2EB`.
- **Text Link / Micro-CTA:** Underlined with a delicate 1px rule offset by `4px`, transitioning from `#1A1918` to `#A45A42` on cursor approach.

### Tactile Badges & Stitch Density Indicators
- **Embroidery Count Badge:** Pill-shaped, minimal background (`#FAF8F5`), 1px border in `#E6E2DA`. Text uses `label-sm` in `#C2A267` (Vintage Wheat) displaying exact stitch volume (e.g., `✦ 48,200 STITCHES`).
- **Material Provenance Tag:** Soft rectangular badge (`roundedness: 1`) in `#F5F2EB` featuring a tiny icon of a needle eye or spool, styled with `#5B6B58` (Sage Thread) typography for organic silk and spun-linen certifications.

### Input Fields & Bespoke Customizers
- **Form Inputs (Monogramming & Text):** Minimalist baseline or framed box with `#F5F2EB` background and a 1px border in `#E6E2DA`. Upon focus, the border transitions to `#1A1918` with zero outer ring glow. Helper copy and active char counts are set in `body-sm` using Flax Grey (`#6B665F`).
- **Thread Swatch Pickers:** Circular buttons (`32px` diameter) displaying physical thread colors, encased in a 2px offset ring that illuminates in `#1A1918` upon selection.

### Product & Editorial Cards
- **Product Tiles:** Frameless layout. The garment or embroidery detail image takes priority (aspect ratio 4:5 or 3:4) resting on `#FFFFFF`. Micro-metadata appears below: Collection Name (`label-sm`), Garment Title (`headline-sm`), and Price (`body-md`) with stitch indicators subtly nested beneath.
- **Hover Micro-Experience:** On desktop cursor hover, the primary editorial photograph dissolves seamlessly over `400ms` into an extreme macro photograph highlighting the raised relief of the embroidery threadwork.

### Lists & Specifications
- **Garment Technical Specs:** Two-column table separated by hairline horizontal rules (`#E6E2DA`). The left column holds technical attributes in uppercase `label-md` (`#6B665F`), while the right column lists atelier responses (e.g., "Thread: 100% Mulberry Silk, Grade 6A") in `body-md` (`#1A1918`).